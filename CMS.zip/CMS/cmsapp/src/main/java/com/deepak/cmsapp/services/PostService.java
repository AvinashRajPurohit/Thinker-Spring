package com.deepak.cmsapp.services;

import java.util.List;

import com.deepak.cmsapp.payloads.PostDto;

public interface PostService {
    
    PostDto createPost(PostDto postDto, Integer userId, Integer categoryId); // create 
    PostDto updatePost(PostDto postDto, Integer postId); // update
    void deletePost(Integer postId);  // delete
    List<PostDto> getAllPost(); // list
    PostDto getPostById(Integer postId); // get
    List<PostDto> getPostsByCategory(Integer categoryId); // list by cat
    List<PostDto> getPostsByUser(Integer userId); // list by user
    List<PostDto> searchPosts(String keyword);



}
