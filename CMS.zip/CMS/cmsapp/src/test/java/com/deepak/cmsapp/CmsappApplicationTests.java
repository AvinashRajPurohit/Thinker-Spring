package com.deepak.cmsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsappApplicationTests {

	@Test
	void contextLoads() {
	}

}
